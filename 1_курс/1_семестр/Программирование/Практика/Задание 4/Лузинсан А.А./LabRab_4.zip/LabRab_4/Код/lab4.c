#include <stdio.h>
#include <math.h>
#include <stdlib.h>

//ВАРИАНТ 10

typedef double dd;
 

dd series(dd x,dd e)
{			
	int i = 2;
	dd y,sum;
	y = pow(x,3)/3; // значение y(1)
	sum = y;	// сумма при x = 1
	
	while(fabs(y) >= e) 
	{	
		
		y =  (y * (x * x) * (2*i + 1) )/( (2*i + 2) * i ); // каждое следущее значение 
		sum = sum + y; // находим сумму 
		i = i + 1; // порядок числа 
	}
		sum *= 2;
		return sum;	
}



int main()
{	
	 dd A,B,E,R; 	

	printf("Bведите значение левого предела интервала (А):");
	scanf("%lf",&A);
	
	printf("\nBведите значение правого предела интервала (B):");
	scanf("%lf",&B);

	while (A >= B)
 	{
		printf("\nВведите корректный интервал (А < B) и (A > 0) !!! \n");
		
		printf("Bведите значение левого предела интервала (А):");
		scanf("%lf",&A);
	
		printf("\nBведите значение правого предела интервала (B):");
		scanf("%lf",&B);
	}


	printf("\nBедите значение допустимой погрешности  (E):");
	scanf("%lf",&E);
	
	while ( (E >= 1) || (E <= 0) )
	{
		printf("\nBведите корректное значение допустимой погрешности  (0 < E < 1)!!!:");
		scanf("%lf",&E);
	}

	printf("\nBведите шаг (R):");
	scanf("%lf",&R);
	
	
		while (R <= 0) 
 		{
			printf("\nBведите корректный шаг (R > 0)!!!:");
			scanf("%lf",&R);
		}

	printf("\n+---------------+\n");  // шапка 
	printf("|   X   |  F(x) |\n");	  // таблицы
	

	while(A <= B)
	{	
		printf("--------+--------\n");   // печать строки
		printf("|%7.2f|%7.2lf|\n",A,series(A,E)); // вывод значений F(x)
		printf("+---------------+\n"); // печать строки

		A = A + R;
	}

	return 0;

}























