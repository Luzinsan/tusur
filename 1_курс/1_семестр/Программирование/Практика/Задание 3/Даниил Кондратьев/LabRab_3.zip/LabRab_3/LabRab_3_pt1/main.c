#include <stdio.h>
#include <stdlib.h>
// #include <windows.h>   работал на линуксе

int main ()
{
//    SetConsoleCP(1251);
//    SetConsoleOutputCP(1251);

   printf("Печатаю сумму N квадратов значений,вычисляемых по правилу\n"
          "\n\ta = i / 3 eсли i кратно 3, в противном случае а = i/(i-3), НОВОЕ и вывожу количество чисел кратное 3!!!!\n"
          "\tгде i = 1,2,...,N.\n"
          "\nВведите значение количества слогаемых: ");

    int N;
    scanf("%d", &N);

/**    Вычислить значение суммы S */

    double a,
           S = 0.0;
    int i = 1,k = 0;

    while(i <= N)
    {
        if(i % 3 == 0)
        {   a = (double) i / 3;
            k = k + 1;
        }
        else
            a = (double) i / (i-3);

        S = S + a * a;
        i = i + 1;

    }

    printf("\n\tПри N = %d имеем S = %8.4f\n"
    "/n количество чисел кратное 3 (k) = %d", N,S,k);

    return 0;
}
