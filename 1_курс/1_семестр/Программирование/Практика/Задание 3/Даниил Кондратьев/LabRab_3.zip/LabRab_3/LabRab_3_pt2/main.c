#include <stdio.h>
#include <stdlib.h>

 void cikl(int e)
{
    int i;

    for(i = 1 ; i*i <= e*e; i++) {

        if ( e % i == 0){

        /*if  (  (i == 2) || (i == 3)  || (i == 5)  ||   (i == 7) || ( ( i % 2 != 0)  && ( i % 3 != 0)  && ( i % 5 != 0) && (i % 7 != 0) )   )
        {

            printf("%d%c", i,','); // являются ли делители простыми ?
         } */

        printf("%d%c", i,',');

        }

    }
}

int main()
{

    int n = 0;

    printf("введите n \n ");

    scanf("%d",&n);

    cikl(n);

    return 0;


}

